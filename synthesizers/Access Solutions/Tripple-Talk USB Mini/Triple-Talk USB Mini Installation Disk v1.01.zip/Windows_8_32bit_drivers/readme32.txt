Access Solutions Inc.
E-Mail: support@axsol.com
Phone: (916) 481-3559



Quick Installation Guide For Vista 32bit, Windows 7 and Windows 8 32bit Systems.
January 23, 2013


To install the Triple-Talk USB or Triple-Talk USB mini in to Windows 7 or Windows 8 32 bit do the 
following:

1.  Connect the synthesizer with a standard "A-B" USB cable to an available 
    USB port on your computer system.

2.  Turn On the synthesizer and go to "Device Manager."

3.  Down arrow or just press the letter "O" until you hear a category named 
    "Other", down arrow till you hear the name of your synthesizer, press 
    enter.

4.  Press "Control Tab" until you hear "Driver Details" then press tab 
    to "Up Date Driver", press enter.

5.  Tab to "Browse My Computer for Driver Software" and press enter.

6.  You will see an edit box, type in the path to the folder where the driver 
    files reside. 
    For example: "c:\temp"

7.  Wait until the computer tells you the drivers have been installed.

8. you will see that the synthesizer has moved from the "Other" category to 
    the Category "Sound/Video and Game Controllers."

9. The synthesizer should be installed and ready to go.

10.  Press "alt F4" until you return to the Start Button.

11. Switch your screen reader to the correct synthesizer selection and press 
    enter.

Note:  If you get the message this driver has not been digitally signed by 
       MicroSoft, just tab to continue anyway and press enter.
