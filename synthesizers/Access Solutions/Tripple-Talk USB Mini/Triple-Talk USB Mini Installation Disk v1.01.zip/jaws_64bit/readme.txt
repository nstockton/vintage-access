
Access Solutions
4536 Edison Ave. 
Sacramento, Ca. 95821
E-Mail: support@axsol.com
Phone: (916) 481-3559

***Important***
Information in this file is intended for an experienced computer user.

jsttu64.jls  -  TripleTalk mini Jaws 64bit driver

The "jsttu64.jls" file in this folder is for use on machines  
running Vista (64bit) or Windows 7 (64bit).
If you are running Jaws 12.0 or later, this file is located in the
following folder:

c:\program files\freedom scientific\jaws\12.0\drivers\speech\jsttu64

For Jaws 12.0 users, you will need to create this folder and copy
the jsttu64.jls file to it. Also, you will need to edit your jfw.ini
and voiceprofiles.ini files and add entries for the TripleTalk USB.
Example .ini files are included in this folder.

