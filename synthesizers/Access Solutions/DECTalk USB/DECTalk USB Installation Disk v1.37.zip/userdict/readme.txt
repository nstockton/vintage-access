
ACCESS SOLUTIONS
4536 Edison Ave.
Sacramento, CA 95821
Web: WWW.AXSOL.COM
Customer support: (916) 481-3559


If you are an advanced user and would like to alter the
pronunciation of specific words spoken by your DECtalk USB, you
may do so by downloading a user dictionary to your unit.  In order
to create a user dictionary, you must first create a .tab file
and then compile the .tab file into a .dic file.  

A .tab file is an ascii text file containing a list of
mispronounced words and their phonemic text representation.  By
changing the phonemic text representation of a given word, you
may alter the way a word is pronounced.  An example of what a
.tab file looks like (example.tab) is included in this folder.  For more
information on phonemic text representation please refer to
chapter 4 of the DECtalk_USB_Commands.txt file located in this folder.

Once you have created a .tab file, the next step is to compile
this file into a .dic file which may be downloaded to your DECtalk
USB.  Compiling of .tab files into .dic files is done via the
supplied windic.exe utility.  There are six different versions of
windic.exe; one for each language spoken by your DECtalk USB. 
Each unique version of windic.exe is contained in its own
individual subfolder.  The subfolders are as follows:

    \userdict\us\windic.exe - U.S. English
    \userdict\uk\windic.exe - U.K. English
    \userdict\sp\windic.exe - Castilian Spanish
    \userdict\la\windic.exe - Latin-American Spanish
    \userdict\fr\windic.exe - French
    \userdict\gr\windic.exe - German

To compile a .tab file into a .dic file you must run one of the
six unique versions of windic.exe.  Under the "File" pull down
menu click on the "Open" selection.  Type in the path and name of
your .tab file and press <Enter>.  Next, under the "File" pull
down menu click on the "Compile Dictionary" selection.  A file
with the same name as your .tab file but with a .dic extention
will be genereated.  This is the file you will download to your
DECtalk USB.  For more information on the windic.exe program, you
may access online help by going to the "Help" pull down menu from
within the windic.exe program.

After you have generated a .dic file, you are now ready to download
this file to your DECtalk USB.  To download your .dic file to your
DECtalk USB follow these steps:

    ***Important: Make sure your DECtalk USB is running a firmware version
                  of 0x0213 or later. To check the firmware version
                  run the \utils\dtuapp.exe program and under the "File"
                  menu click on the "Version Info" selection.
                       To download the latest release of firmware
                       for your DECtalk USB, visit our web site at
                       http://www.axsol.com.
    
    1. Make sure that all software applications that communicate with your  
       DECtalk USB are shut down. If you must run a screen reader,
       change to a software synthesizer such as Eloquence or Sapi.

    2. Run the dtuapp.exe program located in the \utils folder.
    
    3. Under the "Dictionary" pull down menu, click on the "Download
       User Dictionary" selection.
    
    4. Type in the path and file name of your .dic file.
       Example: e:\userdict\my_dic.dic

    5. Select the radio button for which language your user
       dictionary was created.
    
    6. Click on the "Download" button to start the Download process.


         
