                     * JFW / DoubleTalk LT Driver Update *

1. Copy the jsdbltlk.jls file to your JFW directory. If an older copy already
exists in the JFW directory, overwrite it with the file provided with this
update.

2. If you are using a version of JFW earlier than v4.51, you will need to update
the JFW.INI file, also located in the JFW directory. Add the following entries to
the [Synthesizers] section of the JFW.INI file. Again, this should only be necessary
if running a version of JFW earlier than v4.51, as JFW 4.51 and later create these
entries for you if you chose DoubleTalk LT as your synth when installing JFW. If
defined as Synth1, DoubleTalk will be the default synthesizer.

Note: If your DoubleTalk is connected to a port other than Com1, edit the
Synth1Port entry appropriately.

[Synthesizers]
Synth1Name=jsdbltlk
Synth1LongName=Doubletalk LT
Synth1Port=Com1:9600,n,8,1
Synth1Driver=jsdbltlk