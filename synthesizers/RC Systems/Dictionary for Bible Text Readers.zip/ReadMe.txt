Bible Dictionary Downloading Instructions
=========================================

1. Unzip the Bible.dix file from this zip archive to any convenient location.

2. Using RCLink or RCStudio, download the Bible.dix file to the RC8650/RC8660-based product. The file can also be downloaded from a command prompt as follows (change "COM1:" to match the physical port you are using, if different):

Win 9x, Me
----------
MODE COM1:96,N,8,1,P
COPY /B BIBLE.DIX COM1

-or-

Win 2K, XP, Vista, 7
--------------------
MODE COM1: BAUD=9600 PARITY=N DATA=8 STOP=1 OCTS=ON ODSR=OFF RTS=ON
COPY /B BIBLE.DIX COM1

3. The dictionary must now be enabled within the device. Check the device's documentation for instructions on how to do this. If needed, the RC8650/RC8660 command to enable the dictionary is CTRL+A "u" (0x01 "u").
