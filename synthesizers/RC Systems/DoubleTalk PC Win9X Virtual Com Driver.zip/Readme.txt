** DoubleTalk PC/Win9x Virtual COM Port Driver **

This driver allows the DoubleTalk PC to be accessed as a COM port in Windows 9x applications. A new, "virtual" COM port will be created that can be used to send text and commands to DoubleTalk.

Installation

1. Unzip DTPort9x.zip into a directory on your hard drive.

2. From the Windows control panel, select Add New Hardware. Follow the on-screen instructions for adding new hardware manually (do NOT choose to have Windows search for the new hardware).

3. When you are asked to choose a hardware type, choose "Ports (COM & LPT)." When prompted for the manufacturer and model, choose "Have Disk."

4. Complete the installation per the on-screen instructions.

You should now have a new COM port named DoubleTalk PC. You can verify this by checking the installed ports under System Properties | Device Manager | Ports (COM & LPT). The specific COM port emulated will be listed next to the name, e.g., "DoubleTalk PC (COM5)." You can change the character that the driver will use for embedding DoubleTalk commands ("*" by default), under the port's Properties | Settings tab. Clear the text box (null) if you do not wish the driver to treat any character as a command character. (Control-A will always work, regardless of how this option is set.)

In order to be able to "print" data to DoubleTalk from applications that support a print feature, you must set up a text-only printer. Using the Add Printer Wizard, create a Generic / Text Only printer and configure it to print to the DoubleTalk PC port you just created. Note that you can also set up any DoubleTalk commands you wish under the printer's Device Options and/or Fonts properties.